import argparse
import json
import os
from shutil import rmtree
from subprocess import check_call, check_output

def main(args):
    working_dir = os.getcwd()

    empty_users = []
    with open('users.json', 'r') as json_data:
        json_users = json.loads(json_data.read())
        if not os.path.exists('users'):
            os.mkdir('users')

        os.chdir('users')

        # drop most recently modified user folder as it may have been incomplete if interrupted, it will repull
        known_users = sorted([(os.path.getmtime(x), x) for x in os.listdir('.') if x != 'empty_users.txt'], key=lambda t: t[0])
        try:
            rmtree(known_users.pop()[1])
        except IndexError:
            pass # no users yet

        if os.path.exists('empty_users.txt'): # keep track of users who you didn't have convos with
            with open('empty_users.txt', 'r') as f_empty_users:
                for l in f_empty_users:
                    empty_users.append(l.strip())

        for k in json_users:
            dir_name = '_'.join(json_users[k]['name'].split())

            if dir_name in empty_users:
                continue # ignore, already pulled and they're empty
            if os.path.exists(dir_name):
                continue # already parsed user, ignore

            os.mkdir(dir_name)
            os.chdir(dir_name)

            check_call([os.path.join(working_dir, 'scraper'),'-email',args.email,'-password',args.password,'-peer', k])
            parsed = check_output([os.path.join(working_dir, 'messages')])
            with open('parsed.txt', 'w') as parsed_out:
                for l in parsed:
                    parsed_out.write(l)

            if args.no_cleanup_html:
                for f in os.listdir('.'):
                    if '.html' in f:
                        os.remove(f)

            os.chdir('..')
            parsed_path = os.path.join(dir_name, 'parsed.txt')

            if os.path.getsize(parsed_path) == 0: # if parsed is 0 bytes, no convo was had, drop folder, append to empty list
                print "removing {}".format(dir_name)
                rmtree(dir_name)
                with open('empty_users.txt', 'a') as f_empty_users:
                    f_empty_users.write(dir_name+'\n')

if __name__ == "__main__":
    parser = argparse.ArgumentParser()

    parser.add_argument('--email', required=True, help='your hipchat login email (yourusername@somethinglabs.com)')
    parser.add_argument('--password', required=True, help='your hipchat password (yoursecretpassword)')
    parser.add_argument('--no-cleanup-html', action='store_false', required=False, default=True, help='Remove HTML files after creating parsed version')
    args = parser.parse_args()

    main(args)
